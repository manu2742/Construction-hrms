# QA-301: Overtime Entry Screen — Acceptance Criteria
**Ticket:** QA-301
**Type:** Product Brief → Acceptance Criteria
**Author:** manu2742

---

## Context

The PM sent this Slack message:
> "We need an overtime entry screen. Site managers should be able to log
> overtime for their workers at the end of each day — which worker, how many
> hours, what date, and a reason. This needs to work on mobile too since
> they'll enter it at the construction site."

That's the entire requirement. No spec. No wireframe. No edge cases.

---

## Feature Definition

**Who uses it:** Site managers (on mobile, at construction site, end of day)
**What it does:** Log overtime hours for a specific worker on a specific date
**Why it matters:** Overtime hours feed directly into salary calculation → payslip

**Fields required:**
- Worker name (or ID selector)
- Number of overtime hours
- Date
- Reason

---

## Edge Cases the PM Didn't Mention

### Hours Validation
- What if manager enters 0 hours? → Should be rejected (meaningless entry)
- What if manager enters negative hours? → Must be rejected with clear message
- What if manager enters 25 hours in one day? → Impossible, must be rejected
- What if manager enters 999 hours? → Must be rejected
- Decimal hours: is 2.5 hours allowed or only whole numbers?

### Monthly Cap
- Worker already has 58 hours this month against a 60-hour cap
- Manager tries to add 5 more hours
- System must WARN before accepting, not silently cap or silently accept

### Duplicate Entry
- Supervisor A logs 4hrs for Ramesh on June 25
- Supervisor B also logs 3hrs for Ramesh on June 25 (different supervisor)
- System must flag conflict — NOT silently overwrite or sum without warning

### Date Validation
- Can a manager log overtime for yesterday? → Yes (end-of-day entry is normal)
- Can they log for 3 months ago? → Should have a limit (suggest: 7 days back)
- Can they log for a future date? → No — must be rejected

### Mobile / Connectivity
- Construction sites have poor signal
- Form submitted but connection drops mid-way
- On reconnect: must complete OR show retry — must NEVER create duplicate entry
- Form must save draft locally if possible

### Worker Status
- Can manager log overtime for a deactivated/exited worker? → Must be prevented
- Can manager log overtime for a worker from a different site? → Depends on role

---

## Acceptance Criteria (Given/When/Then)

### Happy Path
```
GIVEN a site manager is logged in on mobile
WHEN they select worker "Ramesh Kumar", enter 3 hours, today's date, reason "night shift"
THEN the entry is saved with a confirmation message
AND the overtime hours appear in Ramesh's attendance record
AND his salary calculation reflects the additional hours
```

### Zero Hours Rejected
```
GIVEN a site manager is on the overtime entry form
WHEN they enter 0 in the hours field and submit
THEN the form shows error: "Hours must be greater than 0"
AND no entry is created
```

### Exceeds Daily Maximum
```
GIVEN a site manager is on the overtime entry form
WHEN they enter more than 16 hours for a single day
THEN the form shows error: "Maximum 16 overtime hours per day"
AND no entry is created
```

### Monthly Cap Warning
```
GIVEN worker already has 58 hours overtime this month (60-hour cap)
WHEN manager tries to log 5 more hours
THEN system shows warning: "Worker is near monthly cap (58/60 hours used)"
AND requires manager to confirm before saving
AND saves MAXIMUM of 2 additional hours even if manager entered 5
```

### Duplicate Entry Detection
```
GIVEN supervisor A already logged 4hrs overtime for Ramesh on June 25
WHEN supervisor B tries to log 3hrs for Ramesh on June 25
THEN system shows: "Overtime already logged for this worker on this date"
AND shows existing entry details
AND requires explicit override with justification
```

### Future Date Rejected
```
GIVEN a site manager is on the overtime entry form
WHEN they select a date in the future
THEN the date picker does not allow future dates
OR form shows error: "Cannot log overtime for future dates"
```

### Offline/Connectivity Loss
```
GIVEN a manager partially fills the form on poor mobile connection
WHEN connection drops during submission
THEN on reconnect, the form data is still present (not lost)
AND manager can retry submission
AND only ONE entry is created (no duplicates)
```

---

## Launch Blockers vs v2

### Launch Blockers (must work before go-live)
- Hours validation (0, negative, >16)
- Future date rejection
- Duplicate detection with warning
- Data not lost on connectivity drop
- Entry correctly feeds salary calculation

### v2 (can ship after launch)
- Bulk overtime entry for multiple workers
- Historical correction requests (>7 days ago)
- Offline-first with background sync
- Overtime approval workflow (manager submits → HR approves)

---

## Questions for Dev Before Sprint Starts

1. Is the 60-hour monthly cap enforced in database or only frontend?
2. Who resolves duplicate overtime conflicts — site manager, HR, or payroll?
3. Is overtime rate fixed (1.5x) or configurable per worker/role?
4. What timezone does "today" mean — device timezone or company HQ timezone?
5. Can a worker have multiple overtime entries on the same day from different supervisors?
6. What happens to overtime entries if a worker is deactivated mid-month?
