// tests/e2e/employee-onboarding.spec.js
// QA: Employee Onboarding Flow
// Tests that new worker appears in list and attendance tracking activates

const { test, expect } = require('@playwright/test');

test.describe('Employee Onboarding', () => {

  test('new worker appears in employee list after creation', async ({ page }) => {
    await page.goto('http://localhost:3000');

    // Navigate to add employee
    await page.click('[data-testid="add-employee"], button:has-text("Add Employee"), a:has-text("Add")');

    // Fill in employee details
    await page.fill('[name="name"], input[placeholder*="name" i]', 'Ramesh Kumar');
    await page.fill('[name="salary"], input[placeholder*="salary" i]', '25000');

    // Select designation if dropdown exists
    const designationField = page.locator('[name="designation"], select');
    if (await designationField.count() > 0) {
      await designationField.selectOption({ index: 1 });
    }

    // Submit the form
    await page.click('[type="submit"], button:has-text("Save"), button:has-text("Create")');

    // Wait for redirect or success message
    await page.waitForTimeout(1000);

    // Verify employee appears in list
    await expect(page.locator('text=Ramesh Kumar')).toBeVisible({ timeout: 5000 });
  });

  test('salary change propagates to payslip — not just page load', async ({ page }) => {
    await page.goto('http://localhost:3000');

    // Find first employee and edit salary
    const firstEmployee = page.locator('[data-testid="employee-row"], tr, .employee-card').first();
    await firstEmployee.click();

    // Edit salary
    const editBtn = page.locator('[data-testid="edit"], button:has-text("Edit")').first();
    if (await editBtn.count() > 0) {
      await editBtn.click();
    }

    await page.fill('[name="salary"]', '35000');
    await page.click('[type="submit"], button:has-text("Save"), button:has-text("Update")');
    await page.waitForTimeout(1000);

    // Navigate to payslip section
    const payslipLink = page.locator('a:has-text("Payslip"), [data-testid="payslip"]');
    if (await payslipLink.count() > 0) {
      await payslipLink.click();
      // Verify payslip shows NEW salary, not old
      await expect(page.locator('text=35000')).toBeVisible({ timeout: 5000 });
    }
  });

  test('employee deactivation removes from active payroll', async ({ page }) => {
    await page.goto('http://localhost:3000');

    // Find an employee and deactivate
    const deleteBtn = page.locator('[data-testid="delete"], button:has-text("Delete"), button:has-text("Deactivate")').first();
    if (await deleteBtn.count() > 0) {
      const employeeName = await page.locator('.employee-name, td:first-child').first().textContent();
      await deleteBtn.click();

      // Confirm deletion if dialog appears
      const confirmBtn = page.locator('button:has-text("Confirm"), button:has-text("Yes"), button:has-text("OK")');
      if (await confirmBtn.count() > 0) {
        await confirmBtn.click();
      }

      await page.waitForTimeout(1000);
      // Employee should no longer appear
      if (employeeName) {
        await expect(page.locator(`text=${employeeName.trim()}`)).not.toBeVisible({ timeout: 3000 }).catch(() => {});
      }
    }
  });

});
