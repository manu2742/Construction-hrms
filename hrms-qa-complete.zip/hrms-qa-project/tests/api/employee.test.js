// tests/api/employee.test.js
// API Test Suite — Employee Endpoints
// Covers: happy path, validation, business rules, error responses

const request = require('supertest');

// Adjust this path to match your actual app entry point
let app;
try {
  app = require('../../app');
} catch (e) {
  try {
    app = require('../../server');
  } catch (e2) {
    app = require('../../index');
  }
}

describe('Employee API — Happy Path', () => {

  test('GET /api/employees returns array', async () => {
    const res = await request(app).get('/api/employees');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('POST /api/employees creates employee with valid data', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({
        name: 'Test Worker QA',
        salary: 25000,
        designation: 'Labour'
      });
    expect(res.status).toBe(201);
    expect(res.body.name).toBe('Test Worker QA');
    expect(res.body.salary).toBe(25000);
  });

});

describe('Employee API — Validation (Negative Path)', () => {

  test('POST /api/employees rejects negative salary', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: 'Test', salary: -5000, designation: 'Labour' });
    expect(res.status).toBe(400);
  });

  test('POST /api/employees rejects zero salary', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: 'Test', salary: 0, designation: 'Labour' });
    expect(res.status).toBe(400);
  });

  test('POST /api/employees rejects missing name', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ salary: 25000, designation: 'Labour' });
    expect(res.status).toBe(400);
  });

  test('POST /api/employees rejects empty body — no 500 crash', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({});
    // Should be 400, NOT 500
    expect(res.status).toBe(400);
    expect(res.status).not.toBe(500);
  });

  test('GET /api/employees/undefined returns 404 not 500', async () => {
    const res = await request(app).get('/api/employees/undefined');
    expect(res.status).toBe(404);
    expect(res.status).not.toBe(500);
  });

});

describe('Employee API — Business Rules', () => {

  test('employee salary must be a number, not a string', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: 'Test', salary: 'twenty-five thousand', designation: 'Labour' });
    expect(res.status).toBe(400);
  });

  test('error response contains message, not raw stack trace', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({});
    // Stack trace should NOT be exposed to client
    expect(JSON.stringify(res.body)).not.toContain('at Object.');
    expect(JSON.stringify(res.body)).not.toContain('node_modules');
  });

});
