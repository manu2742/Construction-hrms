// tests/negative/employee-validation.test.js
// QA-303: Automated Negative Tests
// These tests prove bugs exist (fail now) and will pass after fixes

const request = require('supertest');

let app;
try { app = require('../../app'); }
catch (e) { try { app = require('../../server'); } catch (e2) { app = require('../../index'); } }

describe('Negative Tests — Employee Validation', () => {

  test('rejects negative salary — worker cannot get negative pay', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: 'Test', salary: -5000, designation: 'Labour' });
    expect(res.status).toBe(400);
    expect(res.status).not.toBe(201);
  });

  test('rejects zero salary', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: 'Test', salary: 0, designation: 'Labour' });
    expect(res.status).toBe(400);
  });

  test('rejects empty body without crashing server', async () => {
    const res = await request(app).post('/api/employees').send({});
    expect(res.status).toBe(400);
    expect(res.status).not.toBe(500);
  });

  test('does not expose stack trace in error response', async () => {
    const res = await request(app).post('/api/employees').send({});
    const body = JSON.stringify(res.body);
    expect(body).not.toContain('at Object.');
    expect(body).not.toContain('/node_modules/');
    expect(body).not.toContain('MongoError');
  });

  test('rejects XSS payload in name field', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: '<script>alert(1)</script>', salary: 25000, designation: 'Labour' });
    // Either rejected (400) or stored sanitized
    if (res.status === 201) {
      expect(res.body.name).not.toContain('<script>');
    }
  });

  test('rejects SQL injection in name field', async () => {
    const res = await request(app)
      .post('/api/employees')
      .send({ name: "'; DROP TABLE employees;--", salary: 25000, designation: 'Labour' });
    // Should be rejected or sanitized, NOT cause DB error
    expect(res.status).not.toBe(500);
  });

});

describe('Negative Tests — Attendance Validation', () => {

  test('rejects negative hours worked', async () => {
    const res = await request(app)
      .post('/api/attendance')
      .send({ employeeId: 'test', hoursWorked: -3, date: new Date().toISOString() });
    expect(res.status).toBe(400);
  });

  test('rejects more than 24 hours in a day', async () => {
    const res = await request(app)
      .post('/api/attendance')
      .send({ employeeId: 'test', hoursWorked: 25, date: new Date().toISOString() });
    expect(res.status).toBe(400);
  });

});

describe('Negative Tests — Error Handling', () => {

  test('GET non-existent employee returns 404 not 500', async () => {
    const res = await request(app).get('/api/employees/nonexistentid123');
    expect(res.status).not.toBe(500);
  });

  test('GET /api/employees/undefined returns 404 not crash', async () => {
    const res = await request(app).get('/api/employees/undefined');
    expect(res.status).not.toBe(500);
  });

});
