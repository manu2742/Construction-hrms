# Test Strategy — Construction HRMS Payroll
**Project:** mern-employee-salary-management
**Author:** manu2742
**Date:** June 2026

---

## 1. What This System Delivers

One output: **correct payslips for blue-collar construction workers.**

Every feature in this HRMS — attendance tracking, overtime entry, salary
records, employee onboarding — exists for one reason: a daily wage worker
gets paid correctly for the days and hours they worked this month.

A wrong payslip is not a UX bug. It means a family doesn't get paid.

---

## 2. Who Uses This System

| Person | What they do | What breaks for them |
|--------|-------------|----------------------|
| Site Manager | Logs overtime on mobile at construction site | Wrong hours entered = wrong salary |
| HR Team | Manages employee records, salary changes | Wrong record = wrong payslip forever |
| Payroll Operator | Processes 200 workers every month | One bug = 200 wrong payslips, midnight manual work |
| Construction Worker | Receives payslip | Gets wrong pay, can't pay rent this month |
| New Developer | Pushes code without knowing what breaks | No safety net = breaks payroll silently |

---

## 3. The Two Real Incidents (What Already Broke)

**Incident 1 — Missing Environment Variable**
- Developer added feature needing DB connection string
- Added to local .env but NOT to production config
- App crashed on deploy → 4 hours downtime → 200 payslips failed
- 38 workers got payslips 3 days late
- **My test that catches this:** smoke test in CI — app must boot before merge is allowed

**Incident 2 — API Route Typo**
- PR renamed /api/attendance to /api/attendances
- Frontend not updated → 404 for 2 days
- 47 workers' overtime not logged → 12 entries could not be verified
- **My test that catches this:** critical endpoint check in CI smoke suite

---

## 4. Five Critical Flows (Ranked by Business Impact)

### Flow 1: Salary → Payslip Calculation ⚠️ HIGHEST RISK
**Why #1:** Silent failure. Wrong number, no error, no alert. 200 workers affected.
**Worst failure:** Salary updated but old value used in payslip calculation.
**Person hurt:** Every worker whose salary changed this month.
**Test:** Regression suite — salary-payslip.test.js

### Flow 2: Overtime Entry by Site Manager
**Why #2:** Direct cause of Incident 2. Mobile usage at construction sites.
**Worst failure:** Overtime not saved → worker paid for fewer hours than worked.
**Person hurt:** Worker who did night shifts and gets paid as if they didn't.
**Test:** E2E test — overtime-entry.spec.js

### Flow 3: Employee Onboarding
**Why #3:** New worker not created properly = attendance never tracked = ₹0 payslip.
**Worst failure:** Employee created but attendance tracking not activated.
**Person hurt:** New joiner who worked full month, gets nothing.
**Test:** E2E test — employee-onboarding.spec.js

### Flow 4: Attendance Tracking
**Why #4:** Days worked must be recorded accurately for salary calculation.
**Worst failure:** Attendance records silently lost or not linked to employee.
**Person hurt:** Any worker whose attendance disappears from records.
**Test:** API test — attendance.test.js

### Flow 5: Employee Exit / Deactivation
**Why #5:** Deactivated employee still in payroll = corrupt records.
**Worst failure:** Ghost payslips generated for exited employees.
**Person hurt:** Payroll operator who can't reconcile numbers.
**Test:** E2E test — employee-exit.spec.js

---

## 5. What I Will Automate vs Manual

| Flow | Decision | Reason |
|------|----------|--------|
| Salary → Payslip math | **Automate** | Silent failure, affects everyone, no human catches it |
| Overtime E2E | **Automate (Playwright)** | Caused both incidents, critical path |
| API validation + boundaries | **Automate (supertest)** | Fast, exact class of bugs we already saw |
| Negative testing top 5 | **Automate** | Need evidence, not hypotheticals |
| UI layout / CSS | **Manual only** | Nobody gets wrong pay if button is misaligned |
| Performance (200 users) | **Manual note only** | Outside scope, no infra to test properly |
| Password reset | **Skip** | Not payroll-critical |

---

## 6. What I Will NOT Test (and Why)

- **Admin dashboard styling** — not payroll-critical
- **Email notification formatting** — not payroll-critical
- **Browser compatibility (IE/Safari)** — site managers use Chrome on Android
- **Full UI regression suite** — dev lead's constraint: CI must run under 3 minutes

---

## 7. Team Dynamics Accounted For

| Person | Their concern | How my strategy handles it |
|--------|--------------|---------------------------|
| Senior Dev | "QA is overhead, I fix bugs in 20min" | CI runs in <3 min, doesn't slow him down |
| New Dev | "Afraid to touch payroll module" | Regression suite is his safety net |
| PM | "Ship faster AND be reliable" | I protect critical path only, not everything |
| Dev Lead | "20-min test suite kills velocity" | Smoke suite is 30 seconds, full suite <3 min |

---

## 8. Framework: Risk → Impact → Coverage → Prevention

```
RISK                    IMPACT               COVERAGE            PREVENTION
What can go wrong?  →  Who gets hurt?  →  How do I catch it?  →  Stop it recurring?

Salary not           Worker gets         Regression test:        CI blocks merge
propagating to  →    wrong payslip  →   salary-payslip  →       if test fails
payslip              this month         pipeline test

API route typo  →    Overtime not   →   Smoke test:        →    CI checks all
                     logged             endpoint responds        critical routes

Missing env var →    App crashes    →   Smoke test:        →    CI verifies
                     200 payslips       app boots               app starts
                     fail
```
