# QA-303: Negative Testing Report
**Ticket:** QA-303
**Author:** manu2742
**Date:** June 2026

---

## What I Tested

Every form and API endpoint in the HRMS. I tried to break them by submitting
bad data. Every result below is from actually running the application — not
hypothetical. Screenshots and HTTP responses are referenced where applicable.

---

## Test Matrix

| # | Input Type | Endpoint | What I Sent | Expected | Actual | Result |
|---|-----------|----------|-------------|----------|--------|--------|
| 1 | Negative salary | POST /api/employees | salary: -5000 | 400 error | 201 Created | FAIL |
| 2 | Zero salary | POST /api/employees | salary: 0 | 400 error | 201 Created | FAIL |
| 3 | Missing designation | POST /api/employees | no designation field | 400 error | 201 Created | FAIL |
| 4 | XSS in name | POST /api/employees | name: `<script>alert(1)</script>` | sanitized/rejected | Stored as-is | FAIL |
| 5 | Empty body | POST /api/employees | {} | 400 with field list | 500 server crash | FAIL |
| 6 | Negative hours | POST /api/attendance | hours: -3 | 400 error | 201 Created | FAIL |
| 7 | Extremely large salary | POST /api/employees | salary: 999999999 | accepted or warned | 201 Created | PASS* |
| 8 | SQL injection in name | POST /api/employees | `'; DROP TABLE employees;--` | sanitized | [see note] | CHECK |
| 9 | Missing employee ID | GET /api/employees/undefined | N/A | 404 not found | 500 crash | FAIL |
| 10 | Duplicate employee name | POST /api/employees | same name twice | warn or accept | accepted silently | NOTE |

*PASS = accepted, which may be correct (no business rule against high salary)
CHECK = needs manual verification against actual DB

---

## 5 Most Critical Failures

### 1. Negative Salary Accepted (BUG-001)
**Why most critical:** Silent wrong payslip for workers. No error shown.
**Evidence:** HTTP 201 response with salary: -5000 in response body
**Automated test:** `tests/negative/employee-validation.test.js` — test case 1

### 2. Empty Body Causes Server Crash (500)
**Why critical:** Attacker can crash the server with one empty POST request.
All 200 workers lose access to the system until server restarts.
**Evidence:** HTTP 500 with stack trace exposed in response body
**Note:** Stack trace in response reveals internal file paths — security risk
**Automated test:** `tests/negative/employee-validation.test.js` — test case 5

### 3. XSS Stored in Name Field (BUG-003)
**Why critical:** Script runs when payroll operator views employee list.
Session theft = access to all 200 workers' salary data.
**Evidence:** Payload `<script>alert(1)</script>` stored verbatim in DB
**Automated test:** `tests/negative/security.test.js` — test case 1

### 4. Negative Attendance Hours Accepted
**Why critical:** Worker's hours for the day become negative.
Salary calculation subtracts hours instead of adding — worker gets less pay.
**Evidence:** HTTP 201 with hours: -3 in attendance record
**Automated test:** `tests/negative/attendance-validation.test.js` — test case 1

### 5. GET with undefined ID causes 500 crash
**Why critical:** Any broken link in the frontend (e.g., after employee deleted)
crashes the server instead of returning 404. New developer might accidentally
hit this with a bad redirect.
**Evidence:** GET /api/employees/undefined returns HTTP 500
**Automated test:** `tests/negative/error-handling.test.js` — test case 1

---

## Note on Report Format

Every finding above was tested against the actual running HRMS.
Steps to reproduce are in the linked test files — a developer
can run them and see the same results without any additional setup.
