# Quality Process Guide
## For New Developers — Read Before You Push

---

## Why This Exists

Two production incidents in the last 30 days:
1. Missing env variable → app crashed → 200 payslips failed → 38 workers paid late
2. API route typo → 404 for 2 days → 47 workers' overtime not logged

Both were caught too late. Both reached production. Both hurt real people.

This guide makes it impossible to repeat the same class of bug.

---

## Before You Push Code — Checklist

```
[ ] Run: npm test
    → Must be green. If red, fix it before pushing.

[ ] If you changed salary/payslip logic:
    Run: npx jest tests/regression
    → These tests specifically protect the payroll calculation chain.

[ ] If you changed any API route:
    Run: npx jest tests/api
    → Changing /api/attendance to /api/attendances broke production for 2 days.

[ ] If you're not sure what your change affects:
    Ask in Slack — don't guess and push.
```

---

## What CI Checks Automatically (On Every Push)

1. **App boots** — catches missing env variables (Incident 1 pattern)
2. **/api/employees responds** — catches route changes that break the app
3. **/api/payslips responds** — catches payslip endpoint failures
4. **API tests pass** — catches validation regressions
5. **Regression suite passes** — catches salary→payslip propagation failures
6. **Negative tests pass** — catches new ways bad data can enter the system

**Green CI = safe to merge. Red CI = do not merge.**

---

## If CI is Red

1. Click on the failing check in GitHub
2. Read the test name — it describes exactly what failed in plain English
3. Example: `"salary update propagates to payslip"` → you broke the salary update flow
4. Fix the code, not the test
5. If you think the test is wrong, talk to the QA engineer first

---

## The Tests Are Your Safety Net

If you're afraid to touch the payroll module:
- Run the regression suite before you change anything: `npx jest tests/regression`
- Make your change
- Run it again
- If it's still green, you didn't break the payroll chain

You don't need to ask the senior developer every time. The tests tell you.

---

## What This Caught Already

| Pattern | Test That Catches It |
|---------|---------------------|
| Missing env var → crash | Smoke test: app must boot |
| API route renamed → 404 | Smoke test: critical endpoints respond |
| Salary change not in payslip | `salary-payslip.test.js` regression |
| Negative salary accepted | `employee-validation.test.js` |
| Empty body crashes server | `employee-validation.test.js` |

---

## Speed

Full test suite runs in under 3 minutes.
If it goes above 3 minutes — flag it immediately.
A test suite nobody runs because it's slow is worse than no test suite.
