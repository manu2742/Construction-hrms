# Part 3: Summary Sheet Answers
**Author:** manu2742
**Role:** QA Engineer — Construction HRMS

---

## Q1: What does this HRMS exist to deliver, and to whom?

This HRMS delivers one thing: accurate monthly payslips to blue-collar
construction workers. Every feature — attendance tracking, overtime entry,
salary records — exists only to ensure a daily wage worker gets paid correctly
for the days and hours they worked this month. The person who depends on it most
is not an HR admin. It is a construction worker who cannot pay rent if the
number is wrong.

---

## Q2: Most dangerous bug pattern across testing?

Silent data propagation failures — when one entity changes (salary, attendance,
employee status) but the downstream calculation (payslip) does not update. It
is dangerous because it affects 200 workers silently. No error is shown. No
alert is triggered. No human notices until payday, when it is already too late.
The senior dev's fix last sprint was exactly this pattern. My regression suite
now prevents it from coming back.

---

## Q3: Test I am most proud of, and why?

The salary-to-payslip propagation regression test in
`tests/regression/salary-payslip.test.js`. It would have caught the exact bug
the senior developer fixed last sprint before it reached production. The test
fails when the old salary persists in the payslip, and passes only when the
updated salary is correctly used. It protects a specific worker — anyone whose
salary changed this month — from getting paid last month's amount. If this test
had existed before, 200 workers' payslips would have been correct from day one.

---

## Q4: What did I choose NOT to automate, and why?

I did not automate UI layout testing, admin dashboard styling, or password
reset flows. Not because they are hard — because nobody gets a wrong paycheck
if a button is 2px misaligned. The dev lead specifically said a 20-minute CI
pipeline kills velocity. Every test I skipped was a deliberate choice to keep
the suite under 3 minutes and focused on what actually hurts workers when it
breaks.

---

## Q5: One thing I am not fully confident about?

The offline form handling acceptance criteria in QA-301. I wrote the expected
behavior for when a site manager loses connectivity mid-submission at a
construction site. But I could not fully test a real network drop scenario
locally. I documented what should happen and flagged it, but the actual
behavior on a real device with real poor signal needs field testing that I
could not do in this environment.

---

## Q6: What changed between first approach and final submission?

My first test strategy was generic — "functional testing, integration testing,
regression testing, performance testing." I rewrote it completely after asking
one question: if I replaced the project name with "Any HRMS," would this
strategy still read the same? The answer was yes. That meant it was a template,
not a strategy. The final version names specific screens, specific calculations,
specific people, and specific failures from this codebase.

---

## Q7: What I do not know yet that I would need to learn?

1. How the MySQL schema actually handles cascade updates between the salary
   table and payslip table — whether the relationship is enforced at DB level
   or only in application code. This determines whether my regression tests
   catch all propagation failures or only some.

2. Whether the 60-hour monthly overtime cap is a legal requirement under
   Indian labour law or a company policy. Legal requirement changes the
   severity of my acceptance criteria from High to Critical.

3. How the payroll operator actually processes month-end on mobile — which
   screens they use, in what order, and what manual steps they take that the
   system does not automate. I cannot write tests that protect their real
   workflow without watching them work at least once.

---

## Q8: If I had one more day, what would I test?

The full month-end payroll run with all 200 workers processed simultaneously.
I would seed the database with 200 employee records, trigger month-end
calculation, and observe what breaks at scale. Every silent data propagation
bug becomes visible when 200 calculations run at once. Every race condition
in attendance-to-salary updates surfaces under load. That is the moment that
matters most to real workers — and I have not tested it yet.
