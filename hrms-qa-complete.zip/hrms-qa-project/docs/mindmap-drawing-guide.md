# HAND-DRAWN MIND MAP — Exact Drawing Guide
## Draw this on paper with pen. Do NOT use computer. Do NOT use AI.

---

## WHAT TO DRAW — Step by Step

### Paper Setup
- Use A4 paper landscape (wide side horizontal)
- Use blue or black pen
- Write slightly messy — it should look human, not printed

---

## CENTER (Middle of paper)

Draw an oval in the center. Write inside:

```
  QA ENGINEER
Construction
    HRMS
```

---

## THREE MAIN BRANCHES (draw lines going out from center oval)

Draw 3 curved lines going OUT from the center oval:
- One going UP-LEFT
- One going UP-RIGHT  
- One going DOWN

---

## BRANCH 1 — Top Left: PSYCHOLOGY (People)
Write "PSYCHOLOGY" on the branch line going up-left.

Then draw smaller lines branching from it with these labels:

```
PSYCHOLOGY
├── Site Manager
│     └── enters overtime on phone at site
├── Payroll Operator
│     └── processes 200 workers, month-end panic
├── Construction Worker
│     └── needs correct pay THIS month
├── Senior Dev (3 yrs)
│     └── "QA is overhead" → I must prove value
├── New Dev (2 months)
│     └── afraid to touch payroll → needs safety net
└── PM
      └── wants FAST + RELIABLE (not one at the cost of other)
```

---

## BRANCH 2 — Top Right: BUSINESS (What Breaks = Who Gets Hurt)
Write "BUSINESS" on the branch line going up-right.

```
BUSINESS
├── Salary not updated → wrong payslip → worker can't pay rent
├── Incident 1: Missing env var → app crash → 200 payslips fail
├── Incident 2: API typo → 404 → 47 workers' overtime lost
├── Negative salary accepted → ₹0 payslip → worker not paid
└── Deactivated worker still in payroll → corrupt records
```

---

## BRANCH 3 — Bottom: TECHNOLOGY (How I Catch It)
Write "TECHNOLOGY" on the branch line going down.

```
TECHNOLOGY
├── E2E Tests (Playwright)
│     ├── employee-onboarding.spec.js
│     ├── salary-change → payslip propagation
│     └── employee-exit flow
├── API Tests (Supertest)
│     ├── happy path: valid inputs
│     ├── validation: negative salary, empty body
│     └── error handling: 404 not 500
├── Regression Suite
│     └── salary → payslip pipeline
│           (the bug that was fixed last sprint)
├── Negative Tests
│     ├── XSS in name field
│     ├── SQL injection
│     └── boundary values
└── CI Pipeline (GitHub Actions)
      ├── runs on every push to main
      ├── smoke test: app boots
      ├── smoke test: /api/employees responds
      ├── smoke test: /api/payslips responds
      └── BLOCKS merge if any test fails
            → green = safe to deploy
```

---

## CONNECTIONS TO DRAW — THE MOST IMPORTANT PART

After drawing the 3 branches, draw ARROWS connecting them.
These arrows are what makes it a mind map, not 3 separate lists.

Draw these specific connecting arrows with dotted lines (----->):

```
Arrow 1:
Senior Dev's resistance (PSYCHOLOGY)
  ----→ CI must run under 3 minutes (TECHNOLOGY)

Arrow 2:
New Dev's fear (PSYCHOLOGY)
  ----→ Regression suite is his safety net (TECHNOLOGY)

Arrow 3:
Incident 1: env var crash (BUSINESS)
  ----→ Smoke test: app boots in CI (TECHNOLOGY)

Arrow 4:
Incident 2: API route typo (BUSINESS)
  ----→ Smoke test: endpoint check in CI (TECHNOLOGY)

Arrow 5:
Worker depends on correct payslip (PSYCHOLOGY)
  ----→ Salary propagation bug (BUSINESS)
  ----→ Regression test protects it (TECHNOLOGY)
```

---

## HOW YOUR DIAGRAM SHOULD LOOK (Human-Written Style)

DO:
- Write slightly different letter sizes (not perfectly uniform)
- Let some lines curve naturally (not perfectly straight)
- Cross out one word and rewrite it (shows real thinking)
- Add a small star ★ next to the salary→payslip connection (most important)
- Write "MOST CRITICAL" next to one arrow
- Number the connections 1-5

DO NOT:
- Use a ruler (too perfect = looks printed)
- Make all branches exactly the same length
- Use different colored pens unless you have them naturally
- Erase too cleanly

---

## WHAT THE EVALUATOR CHECKS

They will ask: "Can I trace a path from a specific human →
to a specific quality decision → to a specific consequence?"

Your arrows must answer yes.

Example path they want to see:
  New Developer (person)
  → afraid to push code without knowing what breaks (problem)
  → regression suite tells him what's safe to change (quality decision)
  → he can push without asking senior dev every time (consequence)

If your diagram shows this chain — you pass.
If your diagram is three separate lists with no arrows — you fail.
