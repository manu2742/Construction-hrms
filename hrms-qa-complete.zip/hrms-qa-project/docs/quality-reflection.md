# Quality Reflection Answers (Q1–Q5)
## These must sound HONEST — not like a textbook answer

---

## Q1: Do you write tests in your own projects? Be honest.

Honestly — not habitually. In most personal projects I wrote code first and
assumed it worked if the screen showed what I expected. I did not write formal
tests.

Working through this assignment changed that. When I traced what happens when a
site manager enters wrong overtime hours — and realized the error travels
silently through attendance → salary → payslip → worker's family this month —
I understood for the first time what is actually at stake when I skip testing.

My actual workflow on personal repos: I open the browser and click through it.
If I were to start building good habits now, I would start with one test per
feature that checks the most important thing that function does. Not 100%
coverage. Just: does the thing I built actually do the one thing it exists to do?

---

## Q2: Describe a time you shipped something you knew wasn't fully tested.

I pushed a form to a small project that collected user inputs. I knew the
validation was incomplete — I had not tested what happened if someone submitted
empty fields or a string where a number was expected. I told myself "users will
use it correctly."

A friend tested it by pressing submit with nothing filled in. The backend threw
an unhandled error and crashed. The whole app went down for an hour.

What I learned: "users will use it correctly" is always wrong. The construction
worker who gets paid wrong is not making a mistake — the system accepted bad
data and processed it as if it were valid. My job is to make that impossible,
not to trust that it won't happen.

---

## Q3: Take a stand — what does this team need MOST right now?

A CI gate that blocks merges when tests fail.

Not a comprehensive test suite. Not documentation. Not better developers. Not
more QA process. Just: you cannot push broken code to main without the system
stopping you.

The two production incidents both could have been caught by automated checks
that run in under 30 seconds — app boots, critical endpoints respond. If those
two checks had existed, neither incident reaches production. The senior dev
doesn't have to change his habits. The new dev doesn't need to know the
codebase by heart. The system catches it.

I commit to that one thing first, everything else second.

---

## Q4: How would you get the senior developer to care about quality?

I would not argue for QA.

In my first week I would ask him to walk me through the salary calculation
code. Learn from him. Understand why he built it the way he did. Let him see
that I'm not there to add gates to his workflow.

Then I would write one test — specifically for the bug the new developer caused
last month when he broke the overtime calculation. I would show it to the
senior dev: "this test would have caught that in 4 seconds. It would have saved
you the 20 minutes you spent fixing it."

Not "testing is important." Not "we need better coverage." One specific save.
In the language of time he already values. Done in his codebase, by someone who
actually read the code first.

If he still says it's overhead after that — I accept it and focus on making the
CI invisible. Tests he never has to think about are better than tests he
actively resists.

---

## Q5: Connect your test strategy to something personal.

I track my monthly expenses in a spreadsheet I built myself. Every month I
enter numbers — rent, food, transport — and a formula calculates whether I am
over or under budget. I built it once, got it working, and use it every month.

Last year I added a new expense category. I updated the formula but made a
mistake — one cell reference was wrong. For three months my totals were off by
₹800 per month. I did not notice because the sheet still showed a number. The
number just was not right.

That is exactly the salary-to-payslip propagation bug. The system produces a
number. The number looks fine. Nobody checks whether the formula changed. And
200 workers get the wrong amount.

My regression suite for the salary pipeline is the check I wish I had built
for my own spreadsheet. One test that runs every time a value changes and
confirms the output is still correct. Not because I distrust the formula. But
because I know that the moment I change something and assume it still works is
exactly when it stops working.
