#!/bin/bash
# =====================================================
# COMPLETE SETUP SCRIPT FOR MAC
# Run this AFTER you have forked and cloned the HRMS repo
# =====================================================

echo "========================================"
echo " HRMS QA Setup — Step by Step"
echo "========================================"

# STEP 1: Check you are in the right folder
echo ""
echo "Step 1: Checking current folder..."
pwd
ls

echo ""
echo "========================================"
echo " STEP 2: Install dependencies"
echo "========================================"
npm install

echo ""
echo "========================================"
echo " STEP 3: Install test tools"
echo "========================================"
npm install --save-dev jest supertest @playwright/test

echo ""
echo "========================================"
echo " STEP 4: Create QA folder structure"
echo "========================================"
mkdir -p tests/e2e
mkdir -p tests/api
mkdir -p tests/regression
mkdir -p tests/negative
mkdir -p bug-reports
mkdir -p specs
mkdir -p docs
mkdir -p .github/workflows
echo "Folders created."

echo ""
echo "========================================"
echo " STEP 5: Add jest to package.json"
echo "========================================"
# This adds test script if not already there
node -e "
const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
if (!pkg.scripts) pkg.scripts = {};
if (!pkg.scripts.test) pkg.scripts.test = 'jest --forceExit --passWithNoTests';
pkg.jest = { testEnvironment: 'node', testTimeout: 30000 };
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2));
console.log('package.json updated with jest config');
"

echo ""
echo "========================================"
echo " STEP 6: Run tests to verify setup"
echo "========================================"
npm test -- --passWithNoTests

echo ""
echo "========================================"
echo " STEP 7: Push everything to GitHub"
echo "========================================"
git add .
git commit -m "Add QA test suite, CI pipeline, bug reports, acceptance criteria"
git push origin main

echo ""
echo "========================================"
echo " ALL DONE!"
echo "========================================"
echo ""
echo "Now go to:"
echo "  github.com/manu2742/mern-employee-salary-management/actions"
echo ""
echo "You should see the CI pipeline running."
echo "Green check = you passed the technical part."
echo ""
echo "Next steps:"
echo "  1. Draw the mind map on paper (see docs/mindmap-drawing-guide.md)"
echo "  2. Answer the summary questions (see docs/summary-answers.md)"
echo "  3. Submit your GitHub repo link"
