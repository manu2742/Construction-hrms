# HRMS QA Project — Construction Payroll
## By: manu2742

This repo contains the complete QA submission for the Construction HRMS assignment.

## Folder Structure
```
hrms-qa-project/
├── test-strategy.md          ← Part 2: Strategy
├── specs/
│   └── overtime-entry.md     ← QA-301: Acceptance Criteria
├── bug-reports/              ← QA-302: Exploratory Testing
│   ├── BUG-001.md
│   ├── BUG-002.md
│   └── BUG-003.md
├── negative-testing-report.md ← QA-303: Negative Testing
├── tests/
│   ├── e2e/                  ← Playwright E2E tests
│   ├── api/                  ← Supertest API tests
│   ├── regression/           ← QA-304: Regression Suite
│   └── negative/             ← Automated negative tests
├── .github/workflows/
│   └── ci.yml                ← QA-305: CI Pipeline
├── quality-process.md        ← New developer guide
└── docs/
    └── summary-answers.md    ← Part 3: Summary Sheet
```

## How to Run Tests
```bash
npm install
npm test
```

## CI Status
Green build = safe to deploy.
